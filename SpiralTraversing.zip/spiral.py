# -*- coding: utf-8 -*-
"""
Created on Sun Mar 24 12:27:14 2019

@author: Jagriti Singh
"""
import turtle
import random
from random import randint
turtle.bgcolor("black")
seurat=turtle.Turtle()

width=5
height=7

seurat.penup()
list_color = ["white","yellow","brown","red","blue","green","orange","pink","violet","grey","cyan"]
dot_distance =25
seurat.setpos(-250,250)

#m is no of rows and n is no of columns
def spiralprint(m,n):
    k=0
    l=0
    seurat.color("white")
    f=0
    '''
    k is starting index of row
    m is ending row index
    l is starting index of column
    n is ending column index
    i is iterator
    '''
    col = randint(0,10)
    seurat.color(list_color[col])
    
    
    
    while(k<m and l<n):
        if f==1:
            seurat.right(90)
        #printing the first row from the remaining row
        for i in range(l,n):
            seurat.dot()
            seurat.forward(dot_distance)
             #print(a[k][i],end=" ")
        k+=1
        f=1
        
        seurat.right(90)
        col = randint(0,10)
        seurat.color(list_color[col])
        
        #printing the last column from the remaining column
        for i in range(k,m):
            seurat.dot()
            seurat.forward(dot_distance)
            #print(a[i][n-1],end=" ")
        n-=1
        seurat.right(90)
        col=randint(0,10)
        seurat.color(list_color[col])
        
        if(k<m):
            #printing the last row from the remaining row
            for i in range(n-1,l-1,-1):
                seurat.dot()
                seurat.forward(dot_distance)
                #print(a[m-1][i],end=" ")
            m-=1
        seurat.right(90)
        col=randint(0,10)
        seurat.color(list_color[col])
        if(l<n):
            #printing the first column from the remaining columns
            for i in range(m-1,k-1,-1):
                seurat.dot()
                seurat.forward(dot_distance)
                #print(a[i][l],end=" ")
            l+=1
            
            


R=20;C=20
spiralprint(R,C)
turtle.done()